﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShop.Services;
using OnlineShop.Entities;

namespace OnlineShop.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class CategoryController : ControllerBase
	{
		private readonly ICategoryService _categoryService;

		public CategoryController(ICategoryService categoryService)
		{
			_categoryService = categoryService;
		}

		[HttpGet("GetAll")]
		public async Task<ActionResult<IEnumerable<Category>>> GetAll()
		{
			return Ok(await _categoryService.GetAll());
		}

		[HttpGet("GetCategory/{id}")]
		public async Task<ActionResult<Category>> GetCategory(int id)
		{
			var ctg = await _categoryService.GetCategory(id);
			if (ctg == null)
			{
				return BadRequest("Category not found");
			}
			return Ok(ctg);
		}

	}
}
