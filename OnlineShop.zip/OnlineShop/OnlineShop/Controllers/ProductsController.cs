﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShop.Entities;
using OnlineShop.Services;

namespace OnlineShop.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class ProductsController : ControllerBase
	{
		private readonly IProductService _productService;

        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpGet("GetAll")]
		public async Task<ActionResult<IEnumerable<Product>>> GetAll()
		{
			return Ok(await _productService.GetAll());
		}

		[HttpGet("GetFiltered")]
		public async Task<ActionResult<IEnumerable<Product>>> GetFiltered(bool? isVegetarian, bool? hasNuts, int? spiciness, int? categoryId)
		{
			return Ok(await _productService.GetFiltered(isVegetarian, hasNuts, spiciness, categoryId));
		}
	}
}
