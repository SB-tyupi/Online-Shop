﻿using OnlineShop.Repositories;
using OnlineShop.Entities;

namespace OnlineShop.Services
{
	public class CategoryService : ICategoryService
	{
		private readonly ICategoryRepository _categoryRepository;
		public CategoryService(ICategoryRepository categoryRepository)
		{
			_categoryRepository = categoryRepository;
		}

		public async Task<IEnumerable<Category>> GetAll()
		{
			return await _categoryRepository.GetAll();
		}

		public async Task<Category> GetCategory(int id)
		{
			return await _categoryRepository.GetCategory(id);
		}

	}
}
