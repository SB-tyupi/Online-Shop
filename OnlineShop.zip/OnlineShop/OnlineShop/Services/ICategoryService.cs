﻿using OnlineShop.Entities;

namespace OnlineShop.Services
{
	public interface ICategoryService
	{
		Task<IEnumerable<Category>> GetAll();

		Task<Category> GetCategory(int id);
	}
}
