﻿using OnlineShop.Entities;

namespace OnlineShop.Services
{
	public interface IProductService
	{
		Task<IEnumerable<Product>> GetAll();

		Task<IEnumerable<Product>> GetFiltered(bool? isVegetarian, bool? hasNuts, int? spiciness, int? categoryId);
	}
}
