﻿namespace OnlineShop.Dtos
{
	public class BasketDto
	{
		public int ProductId { get; set; }
		public int Quantity { get; set; }
	}
}
